package com.rustcraft;

import com.rustcraft.net.NetworkHandler;
import com.rustcraft.registry.ModCreativeTabs;
import com.rustcraft.registry.ModItems;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

/**
 * Главный класс мода. Здесь только "подключаем" всё остальное:
 *  1) предметы-улучшения (чипы);
 *  2) вкладку креатива "Терминатор";
 *  3) сетевой канал (клиент <-> сервер).
 */
@Mod(RustCraft.MODID)
public class RustCraft {
    public static final String MODID = "rustcraft";

    public RustCraft() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);              // регистрируем чипы
        ModCreativeTabs.TABS.register(modBus);        // регистрируем вкладку креатива
        NetworkHandler.register();                    // регистрируем пакеты
    }
}
