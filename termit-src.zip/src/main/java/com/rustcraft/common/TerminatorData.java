package com.rustcraft.common;

import com.rustcraft.net.NetworkHandler;
import com.rustcraft.net.SyncPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/**
 * Хранит данные терминатора в самом игроке (getPersistentData) —
 * поэтому всё сохраняется между заходами в мир.
 *
 * Три системы (слота улучшений): 0 = Зрение, 1 = Память, 2 = Сканер.
 * У каждой системы три уровня: 0 = повреждён, 1 = средний, 2 = максимальный.
 */
public final class TerminatorData {
    public static final int SYSTEM_COUNT = 3;
    public static final int MAX_LEVEL = 2;

    /** Короткие имена систем (используются в командах: /terminator cycle vision). */
    public static final String[] NAMES = {"vision", "memory", "scanner"};
    /** Названия систем для игрока. */
    public static final String[] TITLES = {"Зрение", "Память", "Сканер"};
    /** Названия уровней для игрока. */
    public static final String[] LEVELS = {"повреждён", "средний", "максимальный"};

    private static final String ACTIVE = "rc_term_active";
    /** Хранится ВЫКЛючение, чтобы у уже существующих игроков ночное зрение по умолчанию было включено. */
    private static final String NIGHT_OFF = "rc_term_night_off";
    private static final String[] KEYS = {"rc_term_vision", "rc_term_memory", "rc_term_scanner"};

    private TerminatorData() {}

    /** Игрок сейчас терминатор? */
    public static boolean isActive(Player p) {
        return p.getPersistentData().getBoolean(ACTIVE);
    }

    /** Ночное зрение (красный экран) включено игроком? По умолчанию да. */
    public static boolean isNightVision(Player p) {
        return !p.getPersistentData().getBoolean(NIGHT_OFF);
    }

    /** Включить / выключить ночное зрение. При выключении снимается наш эффект ночного зрения. */
    public static void setNightVision(ServerPlayer p, boolean on) {
        p.getPersistentData().putBoolean(NIGHT_OFF, !on);
        if (!on) {
            // снимаем только НАШ эффект (он невидимый, без значка), а не настоящее зелье ночного зрения
            MobEffectInstance inst = p.getEffect(MobEffects.NIGHT_VISION);
            if (inst != null && !inst.isVisible() && !inst.showIcon()) p.removeEffect(MobEffects.NIGHT_VISION);
        }
        sync(p);
    }

    /** Текущий уровень системы (всегда 0..2). */
    public static int getLevel(Player p, int system) {
        return Math.max(0, Math.min(MAX_LEVEL, p.getPersistentData().getInt(KEYS[system])));
    }

    /**
     * Стать терминатором. Дороги назад НЕТ: метода "стать человеком" в моде не существует,
     * флаг ACTIVE после этого нигде и никогда не сбрасывается в false.
     */
    public static void activate(ServerPlayer p) {
        p.getPersistentData().putBoolean(ACTIVE, true);
        sync(p);
    }

    /** Поставить уровень системе (обрезается до 0..2). */
    public static void setLevel(ServerPlayer p, int system, int level) {
        int lvl = Math.max(0, Math.min(MAX_LEVEL, level));
        p.getPersistentData().putInt(KEYS[system], lvl);
        // Ночное зрение даёт только Зрение максимального уровня
        if (system == 0 && lvl != MAX_LEVEL) p.removeEffect(MobEffects.NIGHT_VISION);
        sync(p);
    }

    /** Отправить клиенту актуальное состояние (чтобы работали эффекты на экране и экран P). */
    public static void sync(ServerPlayer p) {
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new SyncPacket(isActive(p), getLevel(p, 0), getLevel(p, 1), getLevel(p, 2), isNightVision(p)));
    }

    /** При смерти/возрождении переносим данные в нового игрока. */
    public static void copy(Player from, Player to) {
        // "или": если игрок уже был терминатором — он им и остаётся после смерти/возврата из Энда
        boolean active = from.getPersistentData().getBoolean(ACTIVE) || to.getPersistentData().getBoolean(ACTIVE);
        to.getPersistentData().putBoolean(ACTIVE, active);
        to.getPersistentData().putBoolean(NIGHT_OFF, from.getPersistentData().getBoolean(NIGHT_OFF));
        for (String k : KEYS) to.getPersistentData().putInt(k, from.getPersistentData().getInt(k));
    }
}
