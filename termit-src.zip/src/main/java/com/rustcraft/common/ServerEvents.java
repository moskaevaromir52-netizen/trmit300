package com.rustcraft.common;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/**
 * Серверная логика: команды, превращение в терминатора (необратимое), сбои памяти, ночное зрение.
 * Методы activate / cycle / setLevel — public: их вызывают и команды, и пакет клавиши P, и чипы.
 */
@Mod.EventBusSubscriber(modid = "rustcraft")
public class ServerEvents {

    /** Во сколько раз терминатору ослабляется урон от мобов (0.1 = проходит 10%, как в полной незеритовой броне с чарами). */
    public static final float MOB_DAMAGE_MULTIPLIER = 0.1f;

    // ---------- Команды (/terminator activate, cycle, set) ----------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("terminator");
        root.then(Commands.literal("activate").executes(c -> activate(c.getSource().getPlayerOrException())));

        LiteralArgumentBuilder<CommandSourceStack> cycle = Commands.literal("cycle");
        LiteralArgumentBuilder<CommandSourceStack> set = Commands.literal("set");
        for (int i = 0; i < TerminatorData.SYSTEM_COUNT; i++) {
            final int sys = i;
            cycle.then(Commands.literal(TerminatorData.NAMES[i])
                    .executes(c -> cycle(c.getSource().getPlayerOrException(), sys)));
            set.then(Commands.literal(TerminatorData.NAMES[i])
                    .then(Commands.argument("level", IntegerArgumentType.integer(0, 2))
                            .executes(c -> setLevel(c.getSource().getPlayerOrException(), sys,
                                    IntegerArgumentType.getInteger(c, "level")))));
        }
        root.then(cycle);
        root.then(set);
        e.getDispatcher().register(root);
    }

    // ---------- Действия ----------

    /** Стать терминатором. Обратно в человека вернуться нельзя — никак. */
    public static int activate(ServerPlayer p) {
        if (TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Вы уже терминатор. Пути назад нет."), true);
            return 0;
        }
        TerminatorData.activate(p);
        p.displayClientMessage(Component.literal("Система T-800 активирована. Пути назад нет."), true);
        return 1;
    }

    /** Клавиша H: включить / выключить ночное зрение (вместе с ним выключается красный экран). Только при Зрении максимального уровня. */
    public static int toggleNight(ServerPlayer p) {
        if (!TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Сначала станьте терминатором."), true);
            return 0;
        }
        if (TerminatorData.getLevel(p, 0) < TerminatorData.MAX_LEVEL) {   // только на последнем улучшении
            p.displayClientMessage(Component.literal(
                    "Ночное зрение доступно только при Зрении: максимальный."), true);
            return 0;
        }
        boolean on = !TerminatorData.isNightVision(p);
        TerminatorData.setNightVision(p, on);
        p.displayClientMessage(Component.literal("Ночное зрение: " + (on ? "ВКЛ" : "ВЫКЛ")), true);
        return 1;
    }

    /** Переключить уровень системы по кругу: 0 -> 1 -> 2 -> 0. */
    public static int cycle(ServerPlayer p, int system) {
        if (!TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Сначала станьте терминатором."), true);
            return 0;
        }
        return setLevel(p, system, (TerminatorData.getLevel(p, system) + 1) % 3);
    }

    /** Поставить уровень системы (работает только пока игрок — терминатор). */
    public static int setLevel(ServerPlayer p, int system, int level) {
        if (!TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Сначала станьте терминатором."), true);
            return 0;
        }
        TerminatorData.setLevel(p, system, level);
        p.displayClientMessage(Component.literal(
                TerminatorData.TITLES[system] + ": " + TerminatorData.LEVELS[level] + " (" + level + "/2)"), true);
        return 1;
    }

    // ---------- Синхронизация с клиентом ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) TerminatorData.sync(p);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) TerminatorData.sync(p);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) TerminatorData.sync(p);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        TerminatorData.copy(e.getOriginal(), e.getEntity());
    }

    // ---------- Броня терминатора: почти не получает урон от мобов ----------
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (!TerminatorData.isActive(p)) return;
        // getEntity() — тот, кто нанёс урон (для стрел и взрывов это скелет / крипер), а не сам снаряд
        if (e.getSource().getEntity() instanceof Mob) {
            e.setAmount(e.getAmount() * MOB_DAMAGE_MULTIPLIER);
        }
    }

    // ---------- Эффекты систем (раз в секунду) ----------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != net.minecraftforge.fml.LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer p)) return;
        if (p.tickCount % 20 != 0) return;       // раз в 20 тиков = раз в секунду
        if (!TerminatorData.isActive(p)) return;

        // Зрение максимального уровня = ночное зрение
        if (TerminatorData.getLevel(p, 0) == 2 && TerminatorData.isNightVision(p)) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        }

        // Память: чем хуже уровень, тем чаще сбои
        int mem = TerminatorData.getLevel(p, 1);
        if (mem >= 2) return;
        RandomSource r = p.getRandom();
        if (mem == 0) {
            if (r.nextInt(10) == 0) swapItems(p, r);        // "повреждён": часто меняет предметы местами
            else if (r.nextInt(40) == 0) dropItem(p, r);    // и иногда выбрасывает предмет
        } else if (r.nextInt(40) == 0) {
            swapItems(p, r);                                // "средний": изредка меняет местами
        }
    }

    /** Сбой памяти: два случайных слота (0..35) меняются предметами. */
    private static void swapItems(ServerPlayer p, RandomSource r) {
        Inventory inv = p.getInventory();
        int a = r.nextInt(36), b = r.nextInt(36);
        if (a == b) return;
        ItemStack sa = inv.getItem(a), sb = inv.getItem(b);
        if (sa.isEmpty() && sb.isEmpty()) return;
        inv.setItem(a, sb);
        inv.setItem(b, sa);
        p.displayClientMessage(Component.literal("Сбой памяти: предметы перемещены."), true);
    }

    /** Сбой памяти: случайный непустой слот выбрасывается на землю. */
    private static void dropItem(ServerPlayer p, RandomSource r) {
        Inventory inv = p.getInventory();
        List<Integer> filled = new ArrayList<>();
        for (int i = 0; i < 36; i++) if (!inv.getItem(i).isEmpty()) filled.add(i);
        if (filled.isEmpty()) return;
        int slot = filled.get(r.nextInt(filled.size()));
        ItemStack stack = inv.getItem(slot).copy();
        inv.setItem(slot, ItemStack.EMPTY);
        p.drop(stack, false);
        p.displayClientMessage(Component.literal("Сбой памяти: предмет выброшен."), true);
    }
}
