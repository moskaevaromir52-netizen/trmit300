package com.rustcraft.common;

/** Копия состояния терминатора на стороне клиента (приходит пакетом SyncPacket). */
public final class ClientState {
    public static volatile boolean active;
    public static volatile int vision;
    public static volatile int memory;
    public static volatile int scanner;
    /** Ночное зрение (красный экран) включено? Переключается клавишей H. */
    public static volatile boolean night = true;

    private ClientState() {}

    public static void reset() {
        active = false;
        vision = 0;
        memory = 0;
        scanner = 0;
        night = true;
    }

    /**
     * Показывать красное ночное зрение? Выключить его можно только на максимальном уровне Зрения (клавиша H);
     * на уровнях 0 и 1 оно включено всегда.
     */
    public static boolean redVision() {
        return active && (night || vision < 2);
    }

    /** Уровень системы по номеру слота (0 = зрение, 1 = память, 2 = сканер). */
    public static int level(int system) {
        return system == 0 ? vision : system == 1 ? memory : scanner;
    }
}
