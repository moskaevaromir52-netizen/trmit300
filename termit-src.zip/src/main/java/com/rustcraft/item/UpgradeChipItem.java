package com.rustcraft.item;

import com.rustcraft.common.TerminatorData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Чип улучшения. ПКМ по воздуху = установить в систему терминатора.
 * Один чип = одна система (system) на один уровень (level).
 * Пример: чип "Зрение: максимальный" -> system = 0, level = 2.
 */
public class UpgradeChipItem extends Item {
    private final int system; // 0 зрение, 1 память, 2 сканер
    private final int level;  // 0 повреждён, 1 средний, 2 максимальный

    public UpgradeChipItem(int system, int level) {
        super(new Item.Properties().stacksTo(16));
        this.system = system;
        this.level = level;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!world.isClientSide && player instanceof ServerPlayer sp) {
            if (!TerminatorData.isActive(sp)) {
                sp.displayClientMessage(Component.literal("Сначала станьте терминатором (кнопка P)."), true);
                return InteractionResultHolder.fail(stack);
            }
            TerminatorData.setLevel(sp, system, level);
            sp.displayClientMessage(Component.literal(
                    TerminatorData.TITLES[system] + ": " + TerminatorData.LEVELS[level] + " (" + level + "/2)"), true);
            if (!sp.getAbilities().instabuild) stack.shrink(1); // в креативе чип не тратится
        }
        return InteractionResultHolder.sidedSuccess(stack, world.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level world, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("ПКМ — установить в систему «" + TerminatorData.TITLES[system] + "»"));
        tip.add(Component.literal("Уровень: " + TerminatorData.LEVELS[level] + " (" + level + "/2)"));
    }
}
