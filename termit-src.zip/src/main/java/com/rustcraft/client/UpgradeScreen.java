package com.rustcraft.client;

import com.rustcraft.common.ClientState;
import com.rustcraft.common.TerminatorData;
import com.rustcraft.net.ActionPacket;
import com.rustcraft.net.NetworkHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Окно слотов улучшений (открывается клавишей P, когда игрок уже терминатор).
 * Три слота: Зрение, Память, Сканер. Нажатие на слот переключает уровень 0 -> 1 -> 2 -> 0.
 * Кнопки "стать человеком" нет: превращение в терминатора необратимо.
 */
public class UpgradeScreen extends Screen {
    private final Button[] slotButtons = new Button[TerminatorData.SYSTEM_COUNT];

    public UpgradeScreen() {
        super(Component.literal("Улучшения терминатора"));
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 2 - 40;

        for (int i = 0; i < slotButtons.length; i++) {
            final int system = i;
            slotButtons[i] = Button.builder(Component.empty(),
                            b -> NetworkHandler.CHANNEL.sendToServer(new ActionPacket(ActionPacket.CYCLE, system)))
                    .bounds(x, y + i * 24, 200, 20)
                    .build();
            addRenderableWidget(slotButtons[i]);
        }

        refreshLabels();
    }

    /** Подписи слотов: "Зрение: средний (1/2)". Обновляются каждый тик (состояние приходит с сервера). */
    private void refreshLabels() {
        for (int i = 0; i < slotButtons.length; i++) {
            int lvl = ClientState.level(i);
            slotButtons[i].setMessage(Component.literal(
                    TerminatorData.TITLES[i] + ": " + TerminatorData.LEVELS[lvl] + " (" + lvl + "/2)"));
        }
    }

    @Override
    public void tick() {
        if (!ClientState.active) { // (страховка) состояние ещё не пришло с сервера — окно закрываем
            onClose();
            return;
        }
        refreshLabels();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 62, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false; // игра не ставится на паузу
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        // P ещё раз — закрыть окно
        if (KeyBindings.TERMINATOR_KEY.matches(key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
