package com.rustcraft.client;

import com.rustcraft.common.ClientState;
import com.rustcraft.common.ServerEvents;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Locale;
import java.util.Random;

/**
 * Всё "киношное" оформление зрения терминатора (красный экран, помехи, HUD).
 * Здесь только рисование: данные приходят параметрами из ClientEvents.
 *
 * Уровень зрения влияет на чистоту картинки:
 *   2 (максимальный)  - чистый красный экран, лёгкие строки развёртки;
 *   1 (средний)       - больше шума, тёмные края, редкие сбои;
 *   0 (повреждённый)  - сильные помехи, полосы, мерцание, панели HUD пропадают и рассыпаются.
 */
public final class TerminatorHud {
    private static final Random FX = new Random();
    private static final int RED = 0xD83030;
    private static final String[] LEVEL_WORDS = {"DAMAGED", "MEDIUM", "MAX"};
    private static final String[] WORDS = {"VISUAL", "THERMAL", "MOTION", "BIOMETRIC", "RANGE", "TARGET",
            "THREAT", "MATCH", "ACQUIRE", "TRACK", "SPECTRUM", "SIGNAL"};
    private static final String[] STATES = {"OK", "--", "PENDING", "LOCK", "NULL", "SYNC", "READY"};

    private TerminatorHud() {}

    /** Цвет с прозрачностью: alpha 0..255, rgb без прозрачности. */
    static int argb(int alpha, int rgb) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF);
    }

    // =====================================================================
    //  1) Экран камеры (рисуется ПОД интерфейсом, поверх мира)
    // =====================================================================
    static void renderScreenFx(GuiGraphics g, int w, int h, int tick, int vision) {
        int bad = 2 - vision; // 0 = чисто, 1 = средне, 2 = очень плохо

        // затемнение и красная заливка
        if (vision < 2) g.fill(0, 0, w, h, 0x24000000);
        g.fill(0, 0, w, h, argb(bad == 2 ? 0x28 : bad == 1 ? 0x18 : 0x0A, 0x300000));

        // мерцание яркости и редкая вспышка
        g.fill(0, 0, w, h, FX.nextInt(bad == 2 ? 14 : bad == 1 ? 7 : 3) << 24);
        if (bad == 2 && FX.nextInt(120) == 0) g.fill(0, 0, w, h, argb(0x18, 0xFF4040));

        // строки развёртки
        int step = bad == 2 ? 3 : bad == 1 ? 4 : 6;
        int lineAlpha = bad == 2 ? 0x22 : bad == 1 ? 0x1A : 0x12;
        for (int y = 0; y < h; y += step) g.fill(0, y, w, y + 1, argb(lineAlpha, 0x000000));

        // зерно
        int dots = w * h / (bad == 2 ? 900 : bad == 1 ? 2500 : 8000);
        for (int i = 0; i < dots; i++) {
            int x = FX.nextInt(w), y = FX.nextInt(h);
            int col = FX.nextBoolean() ? 0xE05050 : 0x000000;
            g.fill(x, y, x + 1 + FX.nextInt(2), y + 1, argb(0x20 + FX.nextInt(0x30), col));
        }

        // сбои картинки: горизонтальные полосы со сдвигом
        int chance = bad == 2 ? 12 : bad == 1 ? 80 : 0;
        if (chance > 0 && FX.nextInt(chance) == 0) {
            int y = FX.nextInt(h);
            int hh = 2 + FX.nextInt(bad == 2 ? 6 : 3);
            g.fill(0, y, w, y + hh, argb(0x22, 0xFF3030));
            g.fill(0, y + hh, w, y + hh + 1, argb(0x40, 0x000000));
            int xo = FX.nextInt(Math.max(1, w / 2));
            g.fill(xo, y, xo + w / 3, y + hh, argb(0x28, 0xFF8080));
        }

        // медленная полоса помех (только при самом плохом зрении)
        if (bad == 2) {
            int cycle = tick % 160;
            if (cycle < 30) {
                int by = (int) (cycle / 30.0 * (h + 20)) - 20;
                g.fill(0, by, w, by + 8, argb(0x16, 0xE05050));
                g.fill(0, by + 8, w, by + 10, argb(0x30, 0x000000));
            }
        }

        // виньетка: затемнение по краям кольцами
        int strength = bad == 2 ? 120 : bad == 1 ? 95 : 70;
        int steps = 10;
        int sx = Math.max(2, w / 48), sy = Math.max(2, h / 48);
        for (int i = 0; i < steps; i++) {
            double k = 1.0 - i / (double) steps;
            int col = ((int) (strength * k * k)) << 24;
            int x0 = i * sx, y0 = i * sy, x1 = w - i * sx, y1 = h - i * sy;
            if (x1 <= x0 || y1 <= y0) break;
            g.fill(x0, y0, x1, y0 + sy, col);
            g.fill(x0, y1 - sy, x1, y1, col);
            g.fill(x0, y0 + sy, x0 + sx, y1 - sy, col);
            g.fill(x1 - sx, y0 + sy, x1, y1 - sy, col);
        }
    }

    // =====================================================================
    //  2) HUD терминатора (рисуется ПОВЕРХ интерфейса)
    // =====================================================================
    static void renderHud(GuiGraphics g, Font font, int mode, int w, int h, float yaw, int tick, int bootElapsed,
                          float scanProgress, int targets, int hostiles, int radius, double rng,
                          float hp, float maxHp) {
        int vision = ClientState.vision;
        boolean dropout = vision == 0 && FX.nextInt(12) == 0; // при повреждённом зрении панели иногда пропадают на кадр

        if (mode >= 2) return;               // режим "HUD выключен"
        compass(g, font, w, yaw);
        if (mode == 1) return;               // лёгкий режим: только компас
        frame(g, w, h);
        reticle(g, font, w, h, tick, rng);
        scanBar(g, font, w, h, scanProgress, tick);
        if (!dropout) {
            dataStream(g, font, tick, h, vision);
            statusPanel(g, font, w, tick, targets, hostiles, radius, hp, maxHp);
        }
        boot(g, font, w, h, bootElapsed);
    }

    /** Тонкая рамка по краю экрана с жирными уголками. */
    private static void frame(GuiGraphics g, int w, int h) {
        int c = argb(0xFF, RED), d = argb(0x50, RED);
        int m = 8, len = 26;
        g.fill(m, m, w - m, m + 1, d);
        g.fill(m, h - m - 1, w - m, h - m, d);
        g.fill(m, m, m + 1, h - m, d);
        g.fill(w - m - 1, m, w - m, h - m, d);
        g.fill(m, m, m + len, m + 2, c);                 g.fill(m, m, m + 2, m + len, c);                         // левый верх
        g.fill(w - m - len, m, w - m, m + 2, c);         g.fill(w - m - 2, m, w - m, m + len, c);                 // правый верх
        g.fill(m, h - m - 2, m + len, h - m, c);         g.fill(m, h - m - len, m + 2, h - m, c);                 // левый низ
        g.fill(w - m - len, h - m - 2, w - m, h - m, c); g.fill(w - m - 2, h - m - len, w - m, h - m, c);         // правый низ
    }

    /** Шкала компаса сверху: север/восток/юг/запад и градусы, бегущая при повороте. */
    private static void compass(GuiGraphics g, Font font, int w, float yaw) {
        int cx = w / 2, base = 42;
        float heading = ((yaw % 360f) + 360f + 180f) % 360f; // 0 = север
        g.fill(cx - 112, base, cx + 112, base + 1, argb(0x90, RED));
        for (int d = 0; d < 360; d += 5) {
            float off = ((d - heading + 540f) % 360f) - 180f;
            if (Math.abs(off) > 56f) continue;
            int x = cx + Math.round(off * 2f);
            int alpha = (int) (0xFF * (1f - Math.abs(off) / 60f));
            boolean major = d % 15 == 0;
            g.fill(x, base - (major ? 7 : 4), x + 1, base, argb(alpha, RED));
            if (d % 30 == 0) {
                String lab = d == 0 ? "N" : d == 90 ? "E" : d == 180 ? "S" : d == 270 ? "W" : String.valueOf(d);
                g.drawCenteredString(font, lab, x, base - 19, argb(alpha, RED));
            }
        }
        g.fill(cx, base + 2, cx + 1, base + 7, argb(0xFF, 0xE06060));   // указатель
        g.fill(cx - 2, base + 5, cx + 3, base + 6, argb(0xFF, 0xE06060));
        g.drawCenteredString(font, String.format(Locale.ROOT, "HDG %03d", Math.round(heading) % 360),
                cx, base + 10, argb(0xE0, RED));
    }

    /** Прицел в центре экрана: уголки, перекрестие и дальность до цели под прицелом. */
    private static void reticle(GuiGraphics g, Font font, int w, int h, int tick, double rng) {
        int cx = w / 2, cy = h / 2;
        int r = 20 + (int) Math.round(Math.sin(tick * 0.12) * 2);
        int l = 7;
        int c = argb(0xE0, RED);
        g.fill(cx - r, cy - r, cx - r + l, cy - r + 1, c);  g.fill(cx - r, cy - r, cx - r + 1, cy - r + l, c);
        g.fill(cx + r - l, cy - r, cx + r, cy - r + 1, c);  g.fill(cx + r - 1, cy - r, cx + r, cy - r + l, c);
        g.fill(cx - r, cy + r - 1, cx - r + l, cy + r, c);  g.fill(cx - r, cy + r - l, cx - r + 1, cy + r, c);
        g.fill(cx + r - l, cy + r - 1, cx + r, cy + r, c);  g.fill(cx + r - 1, cy + r - l, cx + r, cy + r, c);
        g.fill(cx - 9, cy, cx - 4, cy + 1, c);  g.fill(cx + 5, cy, cx + 10, cy + 1, c);
        g.fill(cx, cy - 9, cx + 1, cy - 4, c);  g.fill(cx, cy + 5, cx + 1, cy + 10, c);
        String t = rng >= 0 ? String.format(Locale.ROOT, "RNG %.1f", rng) : "RNG ---";
        g.drawCenteredString(font, t, cx, cy + r + 6, c);
    }

    /** Внизу по центру: "SCANNING" с полосой, пока идёт проход сканера. */
    private static void scanBar(GuiGraphics g, Font font, int w, int h, float scanProgress, int tick) {
        int cx = w / 2, y = h - 64, bw = 100;
        boolean scanning = scanProgress >= 0f;
        g.drawCenteredString(font, scanning ? "SCANNING" : "TRACKING", cx, y,
                argb((tick / 10) % 2 == 0 ? 0xFF : 0xA0, RED));
        g.fill(cx - bw / 2, y + 11, cx + bw / 2, y + 12, argb(0x60, RED));
        if (scanning) g.fill(cx - bw / 2, y + 10, cx - bw / 2 + (int) (bw * scanProgress), y + 13, argb(0xFF, RED));
    }

    /** Слева: бегущий вверх поток "данных анализа". */
    private static void dataStream(GuiGraphics g, Font font, int tick, int h, int vision) {
        int x = 16, yTop = 56, lh = 9;
        int rows = Math.max(6, Math.min(16, (h / 2 - yTop) / lh));
        double scroll = tick * 0.35;
        int first = (int) Math.floor(scroll / lh);
        float frac = (float) (scroll - first * (double) lh);
        g.enableScissor(x - 2, yTop, x + 150, yTop + rows * lh);
        for (int k = 0; k <= rows; k++) {
            String line = streamLine(first + k);
            if (vision == 0 && FX.nextInt(6) == 0) line = junk(line);
            int a = 0x40 + (int) (0xA0 * (k / (float) rows));
            g.drawString(font, line, x, Math.round(yTop + k * lh - frac), argb(a, RED), false);
        }
        g.disableScissor();
    }

    /** Строка потока по номеру: всегда одна и та же для одного номера, поэтому поток выглядит как прокрутка. */
    private static String streamLine(int idx) {
        Random r = new Random(idx * 7919L + 104729L);
        switch (r.nextInt(5)) {
            case 0:
                return String.format(Locale.ROOT, "%04X %04X %04X %04X",
                        r.nextInt(0x10000), r.nextInt(0x10000), r.nextInt(0x10000), r.nextInt(0x10000));
            case 1:
                return WORDS[r.nextInt(WORDS.length)] + " " + STATES[r.nextInt(STATES.length)];
            case 2:
                return String.format(Locale.ROOT, "SCAN %03d.%02d", r.nextInt(360), r.nextInt(100));
            case 3:
                return String.format(Locale.ROOT, "%s %d%%", WORDS[r.nextInt(WORDS.length)], r.nextInt(100));
            default:
                return Integer.toBinaryString(0x8000 | r.nextInt(0x8000));
        }
    }

    /** Справа: панель состояния систем (реальные значения). */
    private static void statusPanel(GuiGraphics g, Font font, int w, int tick, int targets, int hostiles,
                                    int radius, float hp, float maxHp) {
        int xR = w - 16, xL = w - 160, y = 56, lh = 11;
        int c = argb(0xE0, RED);
        g.fill(xL - 6, y - 6, xR + 6, y + 10 * lh + 2, argb(0x30, 0x200000));
        g.fill(xL - 6, y - 6, xL - 5, y + 10 * lh + 2, argb(0x80, RED));

        row(g, font, xL, xR, y, "SYSTEM T-800", "ONLINE", c);                         y += lh;
        levelRow(g, font, xL, xR, y, "VISION", ClientState.vision, tick);             y += lh;
        levelRow(g, font, xL, xR, y, "MEMORY", ClientState.memory, tick);             y += lh;
        levelRow(g, font, xL, xR, y, "SCANNER", ClientState.scanner, tick);           y += lh;
        row(g, font, xL, xR, y, "TARGETS", String.valueOf(targets), c);               y += lh;
        row(g, font, xL, xR, y, "HOSTILE", String.valueOf(hostiles), c);              y += lh;
        row(g, font, xL, xR, y, "RADIUS", radius + " M", c);                          y += lh;
        boolean high = hostiles > 3;
        String threat = hostiles == 0 ? "LOW" : high ? "HIGH" : "MEDIUM";
        int tc = (high && (tick / 6) % 2 == 0) ? argb(0xFF, 0xFFFFFF) : argb(0xFF, 0xFF4848);
        row(g, font, xL, xR, y, "THREAT", threat, tc);                                y += lh;
        row(g, font, xL, xR, y, "BODY", Math.round(hp) + "/" + Math.round(maxHp), c); y += lh;
        int cut = Math.round((1f - ServerEvents.MOB_DAMAGE_MULTIPLIER) * 100f);
        row(g, font, xL, xR, y, "MOB DMG", "-" + cut + "%", c);
    }

    private static void row(GuiGraphics g, Font font, int xL, int xR, int y, String label, String value, int color) {
        g.drawString(font, label, xL, y, argb(0xA0, RED), false);
        g.drawString(font, value, xR - font.width(value), y, color, false);
    }

    /** Строка системы с тремя квадратиками уровня и словом (DAMAGED / MEDIUM / MAX). */
    private static void levelRow(GuiGraphics g, Font font, int xL, int xR, int y, String label, int lvl, int tick) {
        g.drawString(font, label, xL, y, argb(0xA0, RED), false);
        for (int i = 0; i < 3; i++) {
            int sx = xL + 58 + i * 7;
            g.fill(sx, y + 1, sx + 5, y + 7, i <= lvl ? argb(0xFF, RED) : argb(0x40, RED));
        }
        String word = (lvl == 0 && (tick / 10) % 2 == 0) ? "ERR" : LEVEL_WORDS[Math.max(0, Math.min(2, lvl))];
        g.drawString(font, word, xR - font.width(word), y, argb(0xE0, lvl == 0 ? 0xE05050 : RED), false);
    }

    /** Заставка включения: красная вспышка и печатающийся текст загрузки систем. */
    private static void boot(GuiGraphics g, Font font, int w, int h, int elapsed) {
        if (elapsed < 0 || elapsed > 130) return;
        if (elapsed < 24) g.fill(0, 0, w, h, argb((int) (0x30 * (1f - elapsed / 24f)), 0xD01010));
        String[] lines = {
                "SYSTEM T-800 // BOOT",
                "VISION ....... " + LEVEL_WORDS[Math.max(0, Math.min(2, ClientState.vision))],
                "MEMORY ....... " + LEVEL_WORDS[Math.max(0, Math.min(2, ClientState.memory))],
                "SCANNER ...... " + LEVEL_WORDS[Math.max(0, Math.min(2, ClientState.scanner))],
                "ARMOR PLATING  OK",
                "ALL SYSTEMS ONLINE"
        };
        int x = w / 2 - 90, y = h / 2 + 56;
        float fade = elapsed > 100 ? (130 - elapsed) / 30f : 1f;
        for (int i = 0; i < lines.length; i++) {
            int chars = (elapsed - (6 + i * 14)) * 2;
            if (chars <= 0) break;
            String t = lines[i].substring(0, Math.min(lines[i].length(), chars));
            boolean last = chars < lines[i].length() || i == lines.length - 1;
            if (last && (elapsed / 4) % 2 == 0) t += "_";
            g.drawString(font, t, x, y + i * 11, argb((int) (0xFF * fade), RED), false);
        }
    }

    /** Случайно портит часть символов (для зрения "повреждён"). */
    static String junk(String s) {
        StringBuilder sb = new StringBuilder(s);
        String junk = "#%&@?/*!";
        for (int i = 0; i < sb.length(); i++) {
            if (FX.nextInt(5) == 0) sb.setCharAt(i, junk.charAt(FX.nextInt(junk.length())));
        }
        return sb.toString();
    }
}
